import sqlite3

def connectDatabase():
    global conn
    conn = sqlite3.connect('test2.db')
      
    print ("Opened database successfully")

def CreateTable():
     conn.execute('''CREATE TABLE IF NOT EXISTS ORDERS
         (USN INTEGER PRIMARY KEY AUTOINCREMENT,
         ORD_NO               INT NOT NULL,
         PURCHASE_AMT                 INT NOT NULL,
         ORD_DATE                INT NOT NULL,
         CUSTOMER_ID          CHAR(50),
         SALESMAN_ID          CHAR(50) NOT NULL);''')

     print ("Table created successfully") 

def CloseDatabase():
      conn.close()
def NewAdmission():
      Salesman_id = int(input("Enter the Salesman_id:"))
      Customer_id = int(input("Enter the Customer_id: "))
      Ord_no = int(input("enter the order no"))
      Ord_date = int(input("enter the order date"))
      Purchase_amt = int(input("enter the purchase amt"))

      conn.execute("INSERT INTO ORDERS (ORD_NO,PURCHASE_AMT,ORD_DATE,CUSTOMER_ID,SALESMAN_ID) \
            VALUES (?,?,?,?,?)",(Ord_no,Purchase_amt,Ord_date,Customer_id,Salesman_id));
      
      
      conn.commit()
def getDataSDetails():
   cursor = conn.execute("SELECT ORD_NO,PURCHASE_AMT,ORD_DATE,CUSTOMER_ID,SALESMAN_ID FROM ORDERS")
   for row in cursor:
      print ("ORD_NO = ", row[0])
      print ("PURCHASE_AMT = ", row[1])
      print ("ORD_DATE = ", row[2])
      print ("CUSTOMER_ID = ", row[3])
      print ("SALESMAN_ID = ", row[4])

def SearchSDetails():
   Ord_no = int(input("Enter the order to view His/Her Details:"))
   cursor = conn.execute("SELECT ORD_NO,PURCHASE_AMT,ORD_DATE,CUSTOMER_ID,SALESMAN_ID FROM ORDERS \
                         WHERE ORD_NO = ?",(Ord_no,))
   for row in cursor:
      print ("ORD_NO = ", row[0])
      print ("PURCHASE_AMT = ", row[1])
      print ("ORD_DATE = ", row[2])
      print ("CUSTOMER_ID = ", row[3])
      print ("SALESMAN_ID = ", row[4],"/n")

def DeleteTuple():
   Ord_no = int(input("ENter the ORD_NO to be Deleted: "))
   conn.execute("DELETE from ORDERS where ORD_NO = ?;",(Ord_no,))
   
   conn.commit()
   print ("Total number of rows deleted:", conn.total_changes)

connectDatabase()
CreateTable()
while True:
      print("\n1. New Admission - All")
      print("2. View  ")
      
      print("3. Search Student Data\n")
      print(" 4. Delete a Tuple")
      print("5. Exit")
      data = int(input())
      if data == 5:
            break;
      elif data == 1:
            NewAdmission()
      elif data == 2:
            getDataSDetails()
      elif data == 3:
            SearchSDetails()
      elif data == 4:
            DeleteTuple()
      else:
            print("Enter a Valid Option")


CloseDatabase()
print("Thank you")