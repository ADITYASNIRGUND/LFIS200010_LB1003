import sqlite3

#It Connects to the DataBase
def connectDatabase():
      global conn
      conn = sqlite3.connect('test.db')

      
      print ("Opened database successfully")

      

      
      
def CreateTable():
    conn.execute('''CREATE TABLE IF NOT EXISTS SALESMAN
         (USN INTEGER PRIMARY KEY AUTOINCREMENT,
         SALESMAN_ID          CHAR(50),
         NAME                 CHAR(50),
         CITY                 CHAR(50),
         COMISSION          INT NOT NULL);''')

    print ("Table created successfully")

         
      

      

    
def CloseDatabase():
      conn.close()
def NewAdmission():
      Salesman_id = int(input("Enter the Salesman_id:"))
      Name = input("Enter the  Name: ")
      City = input("Enter the City: ")
      Commission = int(input("Enter Your Commission:"))
      

      conn.execute("INSERT INTO SALESMAN (SALESMAN_ID,NAME,CITY,COMISSION) \
            VALUES (?,?,?,?)",(Salesman_id,Name,City,Commission));
      
      
      conn.commit()
      
def getDataSDetails():
   cursor = conn.execute("SELECT SALESMAN_ID,NAME,CITY,COMISSION FROM SALESMAN")
   for row in cursor:
      print ("SALESMAN_ID = ", row[0])
      print ("NAME = ", row[1])
      print ("CITY = ", row[2])
      print ("COMISSION = ", row[3])

def SearchSDetails():
   Salesman_id = int(input("Enter the Salesman_id to view His/Her Details:"))
   cursor = conn.execute("SELECT SALESMAN_ID,NAME,CITY,COMISSION FROM SALESMAN \
                         WHERE SALESMAN_ID = ?",(Salesman_id,))
   for row in cursor:
      print ("SALESMAN_ID = ", row[0])
      print ("NAME = ", row[1])
      print ("CITY = ", row[2])
      print ("COMISSION = ", row[3],"/n")

def DeleteTuple():
   Salesman_id = int(input("ENter the Salesman_id to be Deleted: "))
   conn.execute("DELETE from SALESMAN where SALESMAN_ID = ?;",(Salesman_id,))
   conn.commit()
   print ("Total number of rows deleted:", conn.total_changes)

connectDatabase()
CreateTable()
while True:
      print("\n1. New Admission - All")
      print("2. View  ")
      
      print("3. Search Student Data\n")
      print(" 4. Delete a Tuple")
      print("5. Exit")
      data = int(input())
      if data == 5:
            break;
      elif data == 1:
            NewAdmission()
      elif data == 2:
            getDataSDetails()
      elif data == 3:
            SearchSDetails()
      elif data == 4:
            DeleteTuple()
      else:
            print("Enter a Valid Option")


CloseDatabase()
print("Thank you")