import sqlite3

#It Connects to the DataBase
def connectDatabase():
      global conn
      conn = sqlite3.connect('test1.db')

      
      print ("Opened database successfully")


def CreateTable():
    conn.execute('''CREATE TABLE IF NOT EXISTS SALESMAN
         (USN INTEGER PRIMARY KEY AUTOINCREMENT,
         SALESMAN_ID          CHAR(50),
         NAME                 CHAR(50),
         CITY                 CHAR(50),
         COMISSION          INT NOT NULL);''')

    print ("Table created successfully")

def CloseDatabase():
      conn.close()
def NewAdmission():
      Salesman_id = int(input("Enter the Salesman_id:"))
      City = input("Enter the City: ")
      Customer_id = int(input("Enter the Customer_id: "))
      Cust_name = input("Enter the Cust_name: ")
      Grade = int(input("Enter the grade: "))
      

      conn.execute("INSERT INTO CUSTOMER (CUSTOMER_ID,CUST_NAME,CITY,GRADE,SALESMAN_ID) \
            VALUES (?,?,?,?,?)",(Customer_id,Cust_name,City,Grade,Salesman_id));
      conn.commit()


def getDataSDetails():
   cursor = conn.execute("SELECT CUSTOMER_ID,CUST_NAME,CITY,GRADE,SALESMAN_ID FROM CUSTOMER")
   for row in cursor:
      print ("CUSTOMER_ID = ", row[0])
      print ("CUST_NAME = ", row[1])
      print ("CITY = ", row[2])
      print ("GRADE = ", row[3])
      print ("SALESMAN_ID = ", row[4])

def SearchSDetails():
   Customer_id = int(input("Enter the Customer_id's Usn to view His/Her Details:"))
   cursor = conn.execute("SELECT CUSTOMER_ID,CUST_NAME,CITY,GRADE,SALESMAN_ID FROM CUSTOMER \
                         WHERE CUSTOMER_ID = ?",(Customer_id,))
   for row in cursor:
      print ("CUSTOMER_ID = ", row[0])
      print ("CUST_NAME = ", row[1])
      print ("CITY = ", row[2])
      print ("GRADE = ", row[3])
      print ("SALESMAN_ID = ", row[4],"/n")

def DeleteTuple():
   Customer_id = int(input("ENter the CUSTOMER_ID to be Deleted: "))
   conn.execute("DELETE from CUSTOMER where CUSTOMER_ID = ?;",(Customer_id,))
   
   conn.commit()
   print ("Total number of rows deleted:", conn.total_changes)

connectDatabase()
CreateTable()
while True:
      print("\n1. New Admission - All")
      print("2. View  ")
      
      print("3. Search Student Data\n")
      print(" 4. Delete a Tuple")
      print("5. Exit")
      data = int(input())
      if data == 5:
            break;
      elif data == 1:
            NewAdmission()
      elif data == 2:
            getDataSDetails()
      elif data == 3:
            SearchSDetails()
      elif data == 4:
            DeleteTuple()
      else:
            print("Enter a Valid Option")


CloseDatabase()
print("Thank you")